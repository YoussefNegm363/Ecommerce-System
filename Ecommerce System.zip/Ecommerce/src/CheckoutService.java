import java.util.ArrayList;
import java.util.List;

class CheckoutService {
    // Static method to perform checkout for a given customer and their cart.
    public static void checkout(Customer customer, Cart cart)
    {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }

        double subtotal = 0.0;
        double shippingFee = 0.0;
        List<Shippable> shippableItems = new ArrayList<>();// To store products that need shipping

        List<CartItems> validCartItems = new ArrayList<>();// To store items that pass all checks

        for (CartItems item : cart.getItems())
        {
            Product product = item.product;

            if (product.isExpired())
            {
                System.out.println("Product " + product.getName() + " is expired.");
                return;
            }
            // Check if requested quantity is available
            if (item.quantity > product.getQuantity())
            {
                System.out.println("Product " + product.getName() + " is out of stock.");
                return;
            }

            subtotal += item.product.getPrice() * item.quantity;
            validCartItems.add(item);

            if (product instanceof Shippable)
            {
                // If the product needs to be shipped, add to shipping list
                shippableItems.add((Shippable) product);
            }
        }

        if (!shippableItems.isEmpty()) {
            shippingFee = 30.0;
            ShippingService.ship(shippableItems, validCartItems);
        }

        double total = subtotal + shippingFee;
        if (!customer.pay(total)) {
            System.out.println("Insufficient balance.");
            return;
        }

        // reduce product stock
        for (CartItems item : validCartItems) {
            item.product.reduceQuantity(item.quantity);
        }

        // print receipt
        System.out.println("** Checkout receipt **");
        for (CartItems item : validCartItems) {
            System.out.printf("%dx %-12s %.0f\n", item.quantity, item.product.getName(), item.quantity * item.product.getPrice());
        }
        System.out.println("----------------------");
        System.out.printf("Subtotal         %.0f\n", subtotal);
        System.out.printf("Shipping         %.0f\n", shippingFee);
        System.out.printf("Amount           %.0f\n", total);
        System.out.printf("Remaining Balance %.0f\n", customer.getBalance());
        cart.clear();
    }
}