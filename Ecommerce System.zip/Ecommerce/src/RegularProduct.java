// Regular Item (Non-expiring, Non-shippable).
class RegularProduct extends Product {
    public RegularProduct(String Product_Name, double Product_Price, int Quantity)
    {
        super(Product_Name, Product_Price, Quantity);
    }
    @Override
    public boolean isExpired() {
        return false;
    }
}