// Non-expiring shippable product (e.g., TV).
public class ShippableProduct extends Product implements Shippable {
    private double Product_Weight;

    public ShippableProduct(String Product_Name, double Product_Price, int Quantity, double Product_Weight)
    {
        super(Product_Name, Product_Price, Quantity);
        this.Product_Weight = Product_Weight;
    }

    @Override
    public boolean isExpired()
    {
        return false;
    }

    @Override
    public double getWeight()
    {
        return Product_Weight;
    }
}
