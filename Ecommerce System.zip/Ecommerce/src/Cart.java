import java.util.ArrayList;
import java.util.List;

// Shopping Cart.
class Cart {
    // list to hold items added to the cart, using a custom CartItems class.
    private List<CartItems> Items = new ArrayList<>();
    // Adds a product to the cart with the specified quantity.
    public void add(Product product, int quantity)
    {
        // Checks if requested quantity is more than the product's available stock.
        if (quantity > product.getQuantity()) {
            System.out.println("Error: Requested Quantity exceeds Available Stock.");
            return;
        }
        // Returns the list of items currently in the cart.
        Items.add(new CartItems(product, quantity));
    }

    public List<CartItems> getItems()
    {
        // Returns the list of items currently in the cart
        return Items;
    }

    public boolean isEmpty()
    {
        // Checks if the cart is empty
        return Items.isEmpty();
    }

    public void clear()
    {
        // Clears all items from the cart
        Items.clear();
    }
}
