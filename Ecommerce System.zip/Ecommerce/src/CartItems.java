// Class representing an Item in the shopping Cart and its Quantity.
class CartItems {
    Product product;
    int quantity;

    public CartItems(Product product, int quantity)
    {
        this.product = product;
        this.quantity = quantity;
    }
}
