import java.time.LocalDate;
// Expiring but non-shippable product.
public class ExpiringProduct extends Product {
    private LocalDate expirationDate;

    public ExpiringProduct(String Product_Name, double Product_Price, int Quantity, LocalDate expirationDate)
    {
        super(Product_Name, Product_Price, Quantity);
        this.expirationDate = expirationDate;
    }

    @Override
    public boolean isExpired()
    {
        return LocalDate.now().isAfter(expirationDate);
    }
}
