// Define an abstract class named Product.
public abstract class Product {
    //Declare Variables.
    protected String Product_Name;
    protected double Product_Price;
    protected int Quantity;
    // Constructor
    public Product(String Product_Name, double Product_Price, int Quantity)
    {
        this.Product_Name = Product_Name;
        this.Product_Price = Product_Price;
        this.Quantity = Quantity;
    }
    // getter methods
    public String getName() { return Product_Name; }
    public double getPrice() { return Product_Price; }
    public int getQuantity() { return Quantity; }


    // Method to reduce the quantity(stock) of the product by a specified amount
    public void reduceQuantity(int amount)
    {
        this.Quantity -= amount;
    }

    // Abstract method to check if the product is expired (to be implemented by subclasses).
    public abstract boolean isExpired();
}
