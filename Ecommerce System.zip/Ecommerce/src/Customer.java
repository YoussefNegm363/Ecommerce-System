class Customer {
    private double balance;

    public Customer(double balance)
    {
        this.balance = balance;
    }

    public double getBalance()
    {
        return balance;
    }
    // Method to attempt payment with a specified amount.
    public boolean pay(double amount)
    {
        if (amount > balance) return false;
        balance -= amount;
        return true;
    }
}