// Interface for shippable items
interface Shippable {
    String getName();
    double getWeight();
}
