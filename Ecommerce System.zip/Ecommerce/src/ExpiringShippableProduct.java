import java.time.LocalDate;
// Expiring product that is also Shippable.
public class ExpiringShippableProduct extends Product implements Shippable {
    private LocalDate expirationDate;
    private double Product_Weight;

    public ExpiringShippableProduct(String Product_Name, double Product_Price, int Quantity, LocalDate expirationDate, double Product_Weight)
    {
        super(Product_Name, Product_Price, Quantity);
        this.expirationDate = expirationDate;
        this.Product_Weight = Product_Weight;
    }
    // Override the isExpired method from Product class to check if the Item is past its expiration date.
    @Override
    public boolean isExpired() {
        return LocalDate.now().isAfter(expirationDate);
    }
    // Override the getWeight method from the Shippable interface to return the Item's weight.

    @Override
    public double getWeight() {
        return Product_Weight;
    }
}
