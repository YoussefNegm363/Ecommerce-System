import java.time.LocalDate;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Product cheese = new ExpiringShippableProduct("Cheese", 100, 20, LocalDate.of(2025, 8, 1), 200);
        Product biscuits = new ExpiringShippableProduct("Biscuits", 150, 50, LocalDate.of(2025, 8, 1), 700);
        Product tv = new ShippableProduct("TV", 300, 3, 5000);
        Product scratchCard = new RegularProduct("ScratchCard", 50, 5);
        Customer customer = new Customer(50000);
        Cart cart = new Cart();


        cart.add(cheese, 2);
        cart.add(tv, 3);
        cart.add(scratchCard, 1);
        CheckoutService.checkout(customer, cart);
    }
}
