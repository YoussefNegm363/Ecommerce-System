import java.util.List;

class ShippingService {
    // Accepts a list of shippable items and the cart items.
    public static void ship(List<Shippable> shippableItems, List<CartItems> cartItems)
    {
        System.out.println("** Shipment notice **");

        double totalWeight = 0.0;

        // Loop through all cart items
        for (CartItems item : cartItems) {
            // Check if the product in the cart item implements the Shippable interface.
            if (item.product instanceof Shippable) {
                double totalItemWeight = ((Shippable) item.product).getWeight() * item.quantity;
                System.out.printf("%dx %-12s %.0fg\n", item.quantity, item.product.getName(), totalItemWeight);
                totalWeight += totalItemWeight;
            }
        }
        System.out.printf("Total package weight %.1fkg\n\n", totalWeight / 1000);
    }
}